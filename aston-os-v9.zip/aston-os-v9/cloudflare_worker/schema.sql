-- ASTON Society / D1 schema
-- Run once against the Cloudflare D1 database bound as ASTON_DB.

CREATE TABLE IF NOT EXISTS society_profiles (
  tenant_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  display_name TEXT NOT NULL,
  bio TEXT NOT NULL DEFAULT '',
  membership_level TEXT NOT NULL DEFAULT 'MEMBER',
  created_at TEXT NOT NULL,
  PRIMARY KEY (tenant_id, customer_id)
);

CREATE TABLE IF NOT EXISTS society_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  display_name TEXT NOT NULL,
  room TEXT NOT NULL DEFAULT 'lounge',
  body TEXT NOT NULL,
  likes INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_society_posts_room ON society_posts (tenant_id, room, id DESC);

CREATE TABLE IF NOT EXISTS society_likes (
  tenant_id TEXT NOT NULL,
  post_id INTEGER NOT NULL,
  customer_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (tenant_id, post_id, customer_id)
);

CREATE TABLE IF NOT EXISTS customer_preferences (
  tenant_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (tenant_id, customer_id, key)
);
