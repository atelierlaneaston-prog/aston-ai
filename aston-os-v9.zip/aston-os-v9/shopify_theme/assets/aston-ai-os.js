(() => {
  "use strict";
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => {
    if (c === "&") return "&" + "amp;";
    if (c === "<") return "&" + "lt;";
    if (c === ">") return "&" + "gt;";
    if (c === '"') return "&" + "quot;";
    return "&" + "#039;";
  });

const gidNumber = (id) => String(id || "").split("/").pop();

  function boot(root) {
    if (!root || root.dataset.astonReady === "true") return;
    root.dataset.astonReady = "true";
    const endpoint = (root.dataset.endpoint || "").replace(/\/$/, "");
    const tenantId = root.dataset.tenantId || "lane-aston";
    const societyBase = (root.dataset.societyBase || "/apps/aston/society").replace(/\/$/, "");
    const form = root.querySelector("[data-aston-form]");
    const input = root.querySelector("[data-aston-input]");
    const messages = root.querySelector("[data-aston-messages]");
    if (!form || !input || !messages) return;

    const memory = {
      get(key) { try { return localStorage.getItem(key); } catch (e) { return null; } },
      set(key, value) { try { localStorage.setItem(key, value); } catch (e) {} }
    };
    const sessionKey = "aston-session-" + (root.dataset.sectionId || "os");
    let sessionId = memory.get(sessionKey) || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
    memory.set(sessionKey, sessionId);
    let lastProducts = [];
    const fitKey = "aston-fit-" + (root.dataset.sectionId || "os");
    const readFit = () => { try { return JSON.parse(memory.get(fitKey) || "{}"); } catch (e) { return {}; } };
    const writeFit = (profile) => memory.set(fitKey, JSON.stringify(profile));
    const shopRoot = () => (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";

    const api = () => window.ASTON && window.ASTON[root.dataset.sectionId];
    const setState = (state) => { const bridge = api(); if (bridge && bridge.setState) bridge.setState(state); else root.dataset.astonState = state; };
    const open = () => { const bridge = api(); if (bridge && bridge.open) bridge.open(); else root.classList.add("is-open"); };

    function addMessage(text, type) {
      const el = document.createElement("div");
      el.className = "la-aston__message la-aston__message--" + (type === "user" ? "user" : "assistant");
      el.textContent = String(text || "");
      messages.appendChild(el);
      messages.scrollTop = messages.scrollHeight;
      return el;
    }

    function renderProducts(products) {
      if (!Array.isArray(products) || !products.length) return;
      lastProducts = products;
      const wrap = document.createElement("div");
      wrap.className = "la-aston__products";
      products.slice(0, 4).forEach((product) => {
        const card = document.createElement("article");
        card.className = "la-aston__product";
        const img = product.featuredImage?.url ? `<img src="${esc(product.featuredImage.url)}" alt="">` : "<span></span>";
        const price = product.priceRange?.minVariantPrice;
        const variants = (product.variants?.nodes || product.variants || []).filter((v) => v.availableForSale !== false);
        card.innerHTML = `${img}<div><strong>${esc(product.title)}</strong><small>${price ? esc(price.amount) + " " + esc(price.currencyCode) : ""}</small></div>`;
        const body = card.querySelector("div");
        if (variants.length) {
          const select = document.createElement("select");
          select.className = "la-aston__variant";
          variants.forEach((v) => {
            const option = document.createElement("option");
            option.value = v.id;
            option.textContent = v.title || "Default";
            select.appendChild(option);
          });
          const button = document.createElement("button");
          button.type = "button";
          button.className = "la-aston__add";
          button.textContent = "ADD TO BAG";
          button.addEventListener("click", () => addToBag(select.value, 1, button, select.options[select.selectedIndex]?.textContent || ""));
          body.appendChild(select);
          body.appendChild(button);
        }
        if (product.onlineStoreUrl) {
          const link = document.createElement("a");
          link.href = product.onlineStoreUrl;
          link.textContent = "VIEW";
          body.appendChild(link);
        }
        wrap.appendChild(card);
      });
      messages.appendChild(wrap);
      messages.scrollTop = messages.scrollHeight;
    }

    async function checkFit(selectedTitle) {
      const profile = readFit();
      if (root.dataset.fitGate === "false") return true;
      if (!endpoint || !profile.chestCm) return true;
      const response = await fetch(endpoint + "/fit", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Aston-Tenant": tenantId },
        body: JSON.stringify(Object.assign({}, profile, { offset: Number(root.dataset.sizeOffset || 1), market: root.dataset.market || "US", currency: root.dataset.currency || "USD" }))
      });
      const advice = await response.json();
      if (!advice.ready) {
        addMessage(advice.note || "Add chest and waist before ASTON names a size.", "assistant");
        return false;
      }
      const selected = String(selectedTitle || "");
      if (selected && !selected.includes(advice.size)) {
        addMessage("ASTON fit: size " + advice.size + ". " + advice.note, "assistant");
        return window.confirm("ASTON recommends " + advice.size + ". Add the selected size anyway?");
      }
      addMessage("ASTON fit: size " + advice.size + " matches this piece.", "assistant");
      return true;
    }

    async function addToBag(merchandiseId, quantity, button, selectedTitle) {
      const variantId = gidNumber(merchandiseId);
      if (!variantId) return;
      if (button) button.disabled = true;
      setState("thinking");
      try {
        const ok = await checkFit(selectedTitle);
        if (!ok) return;
      } catch (e) {}
      try {
        const response = await fetch(shopRoot() + "cart/add.js", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Accept": "application/json" },
          body: JSON.stringify({ items: [{ id: Number(variantId), quantity }] })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.description || data.message || "Cart update failed.");
        document.documentElement.dispatchEvent(new CustomEvent("cart:refresh", { bubbles: true }));
        document.dispatchEvent(new CustomEvent("cart:updated", { bubbles: true }));
        addMessage("Added to your Lane & Aston bag.", "assistant");
        fetch(shopRoot() + "cart.js").catch(() => {});
      } catch (error) {
        addMessage(error.message || "Could not update the bag.", "assistant");
      } finally {
        setState("online");
        if (button) button.disabled = false;
      }
    }

    async function ask(message) {
      const text = String(message || "").trim();
      if (!text) return;
      open();
      addMessage(text, "user");
      input.value = "";
      if (!endpoint) {
        addMessage("Connect the ASTON Cloudflare endpoint in the section settings.", "assistant");
        return;
      }
      setState("thinking");
      try {
        const response = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Aston-Tenant": tenantId },
          body: JSON.stringify({ message: text, sessionId, channel: "spatial" })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "ASTON is unavailable.");
        if (data.sessionId) {
          sessionId = data.sessionId;
          memory.set(sessionKey, sessionId);
        }
        addMessage(data.reply || data.message || data.text || "I could not form a reply.", "assistant");
        renderProducts(data.products || data.catalogue || []);
        if (root.dataset.speakReplies === "true" && window.speechSynthesis && data.reply) {
          setState("speaking");
          const utter = new SpeechSynthesisUtterance(data.reply);
          utter.lang = document.documentElement.lang || "en-US";
          utter.onend = () => setState("online");
          window.speechSynthesis.speak(utter);
        } else setState("online");
      } catch (error) {
        setState("online");
        addMessage(error.message || "ASTON is temporarily unavailable.", "assistant");
      }
    }

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      ask(input.value);
    });

    root.querySelector("[data-outfit-generate]")?.addEventListener("click", async () => {
      const result = root.querySelector("[data-outfit-result]");
      const button = root.querySelector("[data-outfit-generate]");
      if (!endpoint || !result || !button) return;
      button.disabled = true;
      setState("thinking");
      result.textContent = "ASTON is composing the look.";
      try {
        const response = await fetch(endpoint + "/outfit", {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Aston-Tenant": tenantId },
          body: JSON.stringify({
            occasion: root.querySelector("[data-outfit-occasion]")?.value || "",
            mood: root.querySelector("[data-outfit-mood]")?.value || "",
            palette: root.querySelector("[data-outfit-palette]")?.value || "",
            products: lastProducts.slice(0, 6)
          })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Outfit generation failed.");
        result.innerHTML = (data.image ? `<img alt="ASTON outfit concept" src="data:image/png;base64,${data.image}">` : "") + `<div class="la-aston__outfit-note">${esc(data.note || data.summary || "Concept only. The live catalogue remains the source of truth.")}</div>`;
      } catch (error) {
        result.textContent = error.message;
      } finally {
        button.disabled = false;
        setState("online");
      }
    });

    root.querySelector("[data-vision-analyze]")?.addEventListener("click", async () => {
      const file = root.querySelector("[data-vision-file]")?.files?.[0];
      const out = root.querySelector("[data-vision-result]");
      if (!file || !out || !endpoint) return;
      if (file.size > 6 * 1024 * 1024) { out.textContent = "Use an image under 6 MB."; return; }
      setState("thinking");
      const dataUrl = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
      try {
        const response = await fetch(endpoint + "/vision", { method: "POST", headers: { "Content-Type": "application/json", "X-Aston-Tenant": tenantId }, body: JSON.stringify({ image: dataUrl }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Vision failed.");
        out.textContent = data.summary || data.recommendation || "Style read.";
      } catch (error) {
        out.textContent = error.message;
      } finally { setState("online"); }
    });

    async function loadSociety() {
      if (root.dataset.societyEnabled === "false") return;
      const app = root.querySelector("[data-society-app]");
      const lock = root.querySelector("[data-society-auth]");
      try {
        const response = await fetch(societyBase + "/me", { credentials: "same-origin" });
        if (!response.ok) return;
        const data = await response.json();
        if (!data.customerId && !data.profile) return;
        if (lock) lock.hidden = true;
        if (app) app.hidden = false;
        const profile = root.querySelector("[data-society-profile]");
        if (profile) profile.textContent = data.profile?.display_name || data.displayName || "Member";
      } catch {}
    }

    root.querySelector("[data-aston-view-panel='style']")?.insertAdjacentHTML("beforeend", '<button type="button" class="la-aston__primary" data-add-look>ADD THE LOOK</button>');
    root.querySelector("[data-add-look]")?.addEventListener("click", async () => {
      const cards = root.querySelectorAll(".la-aston__product");
      if (!cards.length) { addMessage("Ask ASTON for a look first.", "assistant"); return; }
      for (const card of cards) {
        const select = card.querySelector("select");
        const button = card.querySelector(".la-aston__add");
        if (select && button) await addToBag(select.value, 1, button, select.options[select.selectedIndex]?.textContent || "");
      }
    });

    const styleView = root.querySelector("[data-aston-view-panel='style']");
    if (styleView && !styleView.querySelector("[data-fit-form]")) {
      const box = document.createElement("form");
      box.dataset.fitForm = "true";
      box.className = "la-aston__studio";
      box.innerHTML = '<label>CHEST CM<input data-fit-chest inputmode="decimal"></label><label>WAIST CM<input data-fit-waist inputmode="decimal"></label><label>FIT<select data-fit-ease><option value="regular">REGULAR</option><option value="relaxed">RELAXED</option><option value="slim">SLIM</option></select></label><button type="submit" class="la-aston__primary">SAVE FIT</button>';
      const saved = readFit();
      styleView.appendChild(box);
      box.querySelector("[data-fit-chest]").value = saved.chestCm || "";
      box.querySelector("[data-fit-waist]").value = saved.waistCm || "";
      box.addEventListener("submit", (event) => {
        event.preventDefault();
        writeFit({ chestCm: Number(box.querySelector("[data-fit-chest]").value), waistCm: Number(box.querySelector("[data-fit-waist]").value), fit: box.querySelector("[data-fit-ease]").value });
        addMessage("Fit profile saved. ASTON will check the size before the bag.", "assistant");
        open();
      });
    }

    root.querySelector("[data-aston-view='society']")?.addEventListener("click", loadSociety);

    if (root.dataset.realtime === "true" && endpoint && window.WebSocket) {
      try {
        const realtime = new WebSocket(endpoint.replace(/^http/, "ws") + "/realtime?sessionId=" + encodeURIComponent(sessionId));
        realtime.onopen = () => { root.dataset.realtimeConnected = "true"; };
        realtime.onclose = () => { root.dataset.realtimeConnected = "false"; };
        root.__astonRealtime = realtime;
      } catch {}
    }
  }

  function start() {
    document.querySelectorAll("[data-la-aston]").forEach(boot);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
  document.addEventListener("shopify:section:load", start);
})();
