# ASTON OS 9.0 — Dawn + Cloudflare, instalacion sin errores

El worker anterior fallaba al crearlo. Esta version no declara KV, D1 ni Durable Objects hasta que existan. El tema Dawn no guarda claves y acepta el origen `*.myshopify.com`.

## 1. Cloudflare

En `cloudflare_worker/wrangler.toml` cambia solo estas dos lineas por tu tienda:

- `SHOPIFY_STORE_DOMAIN = "tu-tienda.myshopify.com"`
- `ASTON_ALLOWED_ORIGIN = "https://tu-tienda.myshopify.com"`

Si ya tienes dominio propio, pon ese dominio en `ASTON_ALLOWED_ORIGIN`. El worker tambien acepta `*.myshopify.com` y la vista previa de Shopify, para que el editor de Dawn no falle por CORS.

```bash
cd cloudflare_worker
npm install
npx wrangler login
npx wrangler deploy
npx wrangler secret put OPENAI_API_KEY
npx wrangler secret put SHOPIFY_STOREFRONT_PRIVATE_TOKEN
```

No crees bindings de KV, D1 ni Durable Object en el dashboard. Un ID falso vuelve a tumbar el deploy.

Prueba en el navegador:

`https://lane-aston-aston-ai.<subdominio>.workers.dev/`

Debe responder `status: online` y `version: 9.0-dawn`.

El endpoint del tema es esa misma URL mas `/api/aston`.

Sin `OPENAI_API_KEY` el worker arranca, pero el chat responde que falta la clave. Sin el token de Storefront, el catalogo responde que Shopify no esta configurado. Eso no es un error de instalacion.

## 2. Dawn

Sube estos archivos en el editor de codigo del tema (o con Shopify CLI):

- `shopify_theme/sections/aston-ai-os.liquid` → `sections/`
- `shopify_theme/snippets/aston-ai-os-assets.liquid` → `snippets/`
- `shopify_theme/assets/aston-ai-os.js` → `assets/`
- `shopify_theme/assets/aston-ai-os.css` → `assets/`

No subas el worker dentro del tema. Dawn no ejecuta Workers.

En `layout/theme.liquid`, justo antes de `</body>`:

```liquid
{% section 'aston-ai-os' %}
```

Una sola vez. No lo agregues tambien en el footer, o el orbe sale duplicado.

En el personalizador, abre la seccion ASTON AI OS y pega:

`https://lane-aston-aston-ai.<subdominio>.workers.dev/api/aston`

Deja Society y Realtime apagados. Society necesita App Proxy. Realtime necesita Durable Object de plan de pago.

Guarda. El carrito usa `cart/add.js` de Dawn con el prefijo de idioma (`Shopify.routes.root`), asi que un mercado `/en/` no rompe el add to bag.

## 3. Lo que no hay que hacer

- No pegar `YOUR_KV_NAMESPACE_ID` ni `YOUR_D1_DATABASE_ID`.
- No activar el binding `ASTON_SESSION` si no pagas Workers y no corriste la migracion.
- No poner `OPENAI_API_KEY` en el tema.
- No usar modelos `gpt-5.6-luna`: no existen y el chat devolvía 500.
