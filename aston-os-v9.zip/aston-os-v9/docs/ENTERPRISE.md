# ASTON 8.0 enterprise

Fail closed. No secret in the theme. No order without a signed Shopify App Proxy.

New worker functions:

- recommend_complete_look(handle): anchor product plus up to three other live pieces.
- gift_by_budget(query, maxAmount, currencyCode): drops anything over budget or in another currency.
- GET /api/aston/orders: 401 unless societyAuth verifies the App Proxy signature and logged_in_customer_id.
- Health reports bindings and version 8.0-enterprise. It does not report token values.

Dawn cart add remains POST /cart/add.js. Storefront cartCreate is the fallback checkout, not the customer bag.
