# ASTON Silicon OS — hito instalable

Esto no es un mock. Es la capa que hace que el orb venda.

## Qué queda conectado

- Dawn section espacial: orb, estados LISTENING / THINKING / SPEAKING, media, cinema.
- `aston-ai-os.js` habla con el Worker y mete la variante en el carrito real de Shopify con `POST /cart/add.js`.
- Worker: Storefront API, AI Gateway, fallback OpenAI, fallback Workers AI si existe el binding `AI`.
- Society solo con App Proxy firmado y `logged_in_customer_id`.
- Webhook Shopify firmado en `POST /api/aston/webhooks/shopify`.
- Durable Object `AstonSession` para el canal realtime.
- D1 para Society. KV para sesión. Analytics Engine y Queue si los bindings existen.

## Orden

1. Theme duplicado. Sube `sections/aston-ai-os.liquid`, `snippets/aston-ai-os-assets.liquid`, `assets/aston-ai-os.js`, `assets/aston-ai-os.css`.
2. En el editor, pega el endpoint `https://TU-WORKER.workers.dev/api/aston`. No pongas claves en el theme.
3. `wrangler secret put` para `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, `OPENAI_API_KEY`, `SHOPIFY_STOREFRONT_PRIVATE_TOKEN`, `SHOPIFY_ADMIN_API_TOKEN`, `SHOPIFY_API_SECRET`, `ASTON_INTERNAL_TOKEN`.
4. Crea KV, D1 y el Durable Object que ya declara `wrangler.toml`. Ejecuta `schema.sql` en D1.
5. App Proxy: prefix `apps`, subpath `aston/society`, URL `https://TU-WORKER.workers.dev/api/aston/society`.
6. Webhook `orders/create` hacia `/api/aston/webhooks/shopify`.
7. Prueba: pregunta de catálogo, Add to bag, carrito de Dawn, Society con cliente logueado.

## Lo que no se finge

Sin token de Storefront el catálogo responde error. Sin App Proxy, Society se queda en la puerta. Sin AI Gateway ni `OPENAI_API_KEY` ni binding `AI`, el concierge no responde. Eso es el comportamiento correcto.
